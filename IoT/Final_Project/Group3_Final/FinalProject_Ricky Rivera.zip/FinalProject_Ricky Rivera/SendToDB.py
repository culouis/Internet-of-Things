import socket
import sys

import mysql.connector as mdb
import random
import string
import datetime
import time

local = 'localhost'
root = 'root'
mypassword = 'mynewpassword'
db = 'GROUP_THREE'

def main():
    
    #Create the socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    #bind the socket to the port
    server_address = ('192.168.0.10', 10055)
    print >> sys.stderr, 'starting up on %s port %d' % server_address
    sock.bind(server_address)

    while True:
        print >>sys.stderr, '\nwaiting to recieve message'
        data, address = sock.recvfrom(16)

        print >>sys.stderr, "\nreceived %s bytes from %s" % (len(data), address)
        print >>sys.stderr, data
        
        devID = 0
        curTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        tc, tt, at  = SeperateData(data)
        fstring = FormatString(devID, tc,tt,at)
        InsertIntoDB(fstring)

#Format a string
def FormatString(devID,sen1,sen2,time):
    return ("INSERT INTO TIMER_TABLE( \
DEVICE_ID, \
TIMERS_CREATED, \
TOTAL_TIME, \
AVG_TIME) \
VALUES(" + str(devID) + "," + str(sen1) +"," + str(sen2) + "," + "'"+str(time) +"'"+ "); ")

def SeperateData(data):
    output = data.split(",")
    y0 = output[0]
    y1 = output[1]
    y2 = output[2]
    return y0, y1, y2
    

#Connect to database, take string and execute query
def InsertIntoDB(string):
    con = mdb.connect(user = root, password = mypassword,host = local, database = db);
    #con = mdb.connect(user = root, password ="",host = local, database = db);
    cursor = con.cursor()
    cursor.execute(string)
    con.commit()
    con.close()

if __name__== "__main__":
    main()


