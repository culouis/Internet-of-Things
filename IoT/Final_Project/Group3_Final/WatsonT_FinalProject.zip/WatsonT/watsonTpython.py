import socket
import sys
import random
from datetime import date, datetime
import time
import mysql.connector



#create the socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

#bind the socket to the port
server_address = ('192.168.0.10', 10004)
print >> sys.stderr, 'starting up on %s port %d' % server_address
sock.bind(server_address)

while True:
    cnx = mysql.connector.connect(user='root', database='GROUP_THREE', password='mynewpassword')
    cursor = cnx.cursor()
    print >>sys.stderr, '\nwaiting to receive message'
    data, address = sock.recvfrom(16)

    print >>sys.stderr, '\nreceived %s bytes from %s' % (len(data), address)
    print >>sys.stderr, data
    vari = data.split(",")
    device = vari[0]
    light = vari[1]
    sound = vari[2]
    insertDate = datetime.now().strftime("%y-%m-%d-%H:%M")

    data = ('INSERT INTO LIGHT_SOURCE'
            '(DEVICE_ID, LIGHT_STATUS, SOUND_STATUS, INSERT_DATE)'
            'VALUES (\'%s\', \'%s\', \'%s\', \'%s\')'%(device, light, sound, insertDate))
    print (data)
    cursor.execute(data)
    cnx.commit()
    cursor.close()
    cnx.close()
