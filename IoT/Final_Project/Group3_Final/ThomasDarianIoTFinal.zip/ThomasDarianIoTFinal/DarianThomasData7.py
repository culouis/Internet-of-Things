
import socket
import sys
import mysql.connector
from datetime import datetime




sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

server_address = ('192.168.0.10', 10022)
print >> sys.stderr, 'starting up on %s port %d' % server_address
sock.bind(server_address)

print >>sys.stderr, '\nwaiting to recieve message'
data, address = sock.recvfrom(16)


while True:
    cnx = mysql.connector.connect(user='root', database='GROUP_THREE', password='mynewpassword')

    cursor = cnx.cursor()

    #CREATES the VALUES
    output = data.split(",")
    farData = output[1]
    celData = output[0]
    deviceID = 'device10009'
    insertDate = datetime.now().strftime("%y-%m-%d-%H:%M")

    add_TODB = 'INSERT INTO TEMP_TABLE (DEVICE_ID, \
    CEL_DATA,\
    FAR_DATA,\
    DATE_)  VALUES (\'%s\',\'%s\', \'%s\', \'%s\')'%(deviceID,celData,farData,insertDate)

    cursor.execute(add_TODB)

    cnx.commit()




cursor.close()
cnx.close()
