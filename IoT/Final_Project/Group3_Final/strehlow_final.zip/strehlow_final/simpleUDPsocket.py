import socket
import sys
import mysql.connector as mdb
import random
import string

local = 'localhost'
root = 'root'
mypassword = 'mynewpassword'
databaseid = 'GROUP_THREE'

def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    server_address = ('192.168.0.10', 10006)
    print >> sys.stderr, 'starting up on %s port %d' % server_address
    sock.bind(server_address)

    while True:
        print >>sys.stderr, '\nwaiting to recieve message'
        data, address = sock.recvfrom(16)

        print >>sys.stderr, "\nreceived %s bytes from %s" % (len(data), address)
        print >>sys.stderr, data

        deviceID = 0
        tilt, light  = seperate(data)
        data_string = FormatString(deviceID, tilt, light)
        database(data_string)

def FormatString(deviceID,sen1,sen2):
    return ("INSERT INTO TILT_TABLE( \
    DEVICE_ID, \
    TILT_READ, \
    LIGHT_OUTPUT) \
    VALUES(" + str(deviceID) + "," + str(sen1) +"," + str(sen2))

def seperate(data):
    output = data.split(",")
    one = output[0]
    two = output[1]
    return one, two


def database(string):
    con = mdb.connect(user = root, password = mypassword,host = local, database = databaseid);
    cursor = con.cursor()
    cursor.execute(string)
    con.commit()
    con.close()

if __name__== "__main__":
    main()
